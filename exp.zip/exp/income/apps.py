from django.apps import AppConfig


class IncomeConfig(AppConfig):
    name = 'income'
