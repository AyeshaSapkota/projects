from django.urls import path
from . import views

urlpatterns = [
    path('signin/',views.signin,name='login'),
    path('signup/',views.signup, name ='signup'),
    path('signup/', views.signup, name='logout'),
    path('dashboard/',views.dashboard,name='dashboard'),
    path('dashboard/income',views.income,name='income'),
    path('dashboard/expenses',views.expenses,name='expenses'),
    path('dashboard/category',views.category,name='category')
]