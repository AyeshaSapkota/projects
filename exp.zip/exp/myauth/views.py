from django.shortcuts import render,redirect
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import authenticate,login
from income.forms import IncomeForm
from category.forms import CategoryForm
from category .models import Category
from income.models import Income
from expenses.forms import ExpensesForm
# Create your views here.
def signin(request):
    if request.method=='GET':
        return render(request,'signin.html')
    else:
        u=request.POST.get("username")
        p=request.POST.get("password")
        user=authenticate(username=u,password=p)
        if user is not None:
            login(request,user)
            return redirect('dashboard')
        return render(request,'signin.html',{'errmsg':'your username or password is incorresct'})

def signup(request):
    if request.method=='GET':
        context = {
            'form':UserCreationForm()
        }

        return render(request,'signup.html',context)
    else:
        form=UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('login')
        return render(request,'signup.html',{'form':form})

def dashboard(request):
    return render(request,'dashboard.html')

def income(request):
    if request.method=='GET':

        context = {
            'form':IncomeForm(),
            'income': Income.objects.filter(user_id=request.user.id)
        }
        return render(request,'income.html',context)
    else:
        form=IncomeForm(request.POST)
        if form.is_valid():
            data=form.save(commit=False)
            data.user_id = request.user.id
            data.save()
            return redirect('income')
        return render(request,'income.html',{'form':form})

def expenses(request):
    if request.method=='GET':
        context ={
            'form': ExpensesForm()

        }
        return render(request,'expenses.html',context)
    else:
        form=ExpensesForm(request.POST)
        if form.is_valid():
            data=form.save(commit=False)
            data.user_id=request.user.id
            data.save()
            return redirect('expenses')
    return render(request,'expenses.html')

def category(request):
    if request.method=='GET':
        context ={
            'form': CategoryForm(),
            'cat': Category.objects.filter(user_id=request.user.id)
        }
        return render(request,'category.html',context)
    else:
        form=CategoryForm(request.POST)
        if form.is_valid():
            data=form.save(commit=False)
            data.user_id=request.user.id
            data.save()
            return redirect('category')
        return render(request,'category.html',{'form':form})






